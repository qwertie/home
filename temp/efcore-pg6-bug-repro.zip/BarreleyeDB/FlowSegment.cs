﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace BarreleyeCommon.Models
{
    [Serializable] // only needed until we switch serializers
    public class FlowSegment : IEquatable<FlowSegment>
    {
        public DateTime StartDate { get; set; }
        
        // Note: this has amounts for each day, even though the solver's 
        //       timestep is not necessarily 24 hours.
        public double[] Amounts { get; set; } = Array.Empty<double>();

        public double this[int index] => (uint)index < (uint)Amounts.Length ? Amounts[index] : 0;

        [JsonIgnore]
        public DateTime EndDate => StartDate.AddDays(Amounts.Length);

        public FlowSegment() => Amounts = Array.Empty<double>();
        public FlowSegment(DateTime startDate, params double[] amounts)
        {
            StartDate = startDate;
            Amounts = amounts;
        }

        public void RoundOff(int decimals)
        {
            for (int i = 0; i < Amounts.Length; i++)
                Amounts[i] = Math.Round(Amounts[i], decimals);
        }

        public override bool Equals(object? obj) => Equals(obj as FlowSegment);

        public bool Equals(FlowSegment? other)
            => other != null
            && StartDate == other.StartDate
            && Amounts.SequenceEqual(other.Amounts);

        //public override int GetHashCode() => StartDate.GetHashCode() ^ Amounts.SequenceHashCode();

        //public override string ToString() => $"FlowSegment({ParamString()})";
        //protected string ParamString()
        //{
        //    string date = StartDate.ToTestString();
        //    return Amounts.Any() ? date + ", " + string.Join(",", Amounts.Select(a => Math.Round(a))) : date;
        //}

        //public static FlowSegment? Combine(IEnumerable<FlowSegment> segments)
        //{
        //    if (!segments.Any())
        //        return null;
        //    var min = segments.Aggregate((DateTime?)null, (min, seg) => Misc.Min(min, seg.StartDate));
        //    var max = segments.Aggregate((DateTime?)null, (max, seg) => Misc.Max(max, seg.EndDate));
        //    var timeline = DateRangeWithTimeStep.OfOneDay(min!.Value, max!.Value);
        //    var array = new double[timeline.EndTimeIndex];
        //    foreach (var segment in segments)
        //    {
        //        int tStart = timeline.TimeIndexOf(segment.StartDate);
        //        for (int t = tStart; t < tStart + segment.Amounts.Length; t++)
        //            array[t] += segment.Amounts[t - tStart];
        //    }
        //    return new FlowSegment(timeline.Start, array);
        //}

        /// <summary>Removes zero flow days from start and end of flow.</summary>
        public void Trim(double epsilon = 0)
        {
            (int startIndex, int stopIndex) = GetTrimBounds(epsilon);
            Amounts = Amounts.AsSpan().Slice(startIndex, stopIndex - startIndex).ToArray();
            StartDate = StartDate.AddDays(startIndex);
        }

        (int startIndex, int stopIndex) GetTrimBounds(double epsilon = 0)
        {
            int startIndex = 0, stopIndex = Amounts.Length;
            while (stopIndex > 0 && Math.Abs(Amounts[stopIndex - 1]) <= epsilon)
                stopIndex--;
            while (startIndex < stopIndex && Math.Abs(Amounts[startIndex]) <= epsilon)
                startIndex++;
            return (startIndex, stopIndex);
        }

        public int GetTrimmedLength(double epsilon = 0)
        {
            var b = GetTrimBounds(epsilon);
            return b.stopIndex - b.startIndex;
        }

        // DP: this is based on the extendDataSeries() function that I wrote in TypeScript.
        /// <summary>
        /// Adds additional array elements to a FlowSegment so that it includes the specified
        /// time index, under the assumption that the timestep is one day. The index is 
        /// specified relative to the FlowSegment, e.g. if index is -2, it means that an 
        /// array element needs to exist two days before the current start date, so two 
        /// values equal to defaultDatum are added at the beginning of `data.amounts`. 
        /// </summary>
        /// <returns>
        /// The return value indicates the new value of index such that it refers to the same
        /// point in time; it is always equal either to zero, or to the `index` argument.
        /// </returns>
        public int ExtendToIndex(int index, double defaultDatum = 0)
        {
            if (this.Amounts.Length == 0) {
                this.StartDate = this.StartDate.AddDays(index);
                this.Amounts = new[] { defaultDatum };
                return 0;
            } else if (index < 0 || this.Amounts.Length == 0) {
                var amounts2 = new double[-index + Amounts.Length];
                Array.Fill(amounts2, defaultDatum, 0, -index);
                Array.Copy(Amounts, 0, amounts2, -index, Amounts.Length);
                this.StartDate = this.StartDate.AddDays(index);
                this.Amounts = amounts2;
                return 0;
            } else if (index >= this.Amounts.Length) {
                int extra = index + 1 - this.Amounts.Length;
                var amounts2 = new double[index + 1];
                Array.Copy(Amounts, 0, amounts2, 0, Amounts.Length);
                Array.Fill(amounts2, defaultDatum, Amounts.Length, extra);
                this.Amounts = amounts2;
            }
            return index;
        }

        //public int ExtendTo(DateTime date, double defaultDatum = 0) =>
        //    ExtendToIndex(DateRangeWithTimeStep.TimeIndexOf(date, StartDate, TimeSpan.FromDays(1)), defaultDatum);
    }
}
