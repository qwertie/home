﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Diagnostics;
using System.Linq.Expressions;

namespace Barreleye
{
    public static class DbMisc
    {
        public static PropertyBuilder HasConversion<ModelT, DBT>(this PropertyBuilder property,
            Expression<Func<ModelT, DBT>> onSave, Expression<Func<DBT, ModelT>> onLoad, ConverterMappingHints? hints = null)
            => property.HasConversion(new ValueConverter<ModelT, DBT>(onSave, onLoad, hints));

        // Normally PostgreSQL doesn't store timezone info. This method saves as UTC,
        // and also marks as UTC on load so that the date is sent to the front-end in
        // UTC format.
        public static PropertyBuilder HasUtcConversion(this PropertyBuilder prop)
            => prop.HasConversion<DateTime, DateTime>(d => d.ToUniversalTime(), d => IsAlreadyUtc(d));
        public static PropertyBuilder NullableHasUtcConversion(this PropertyBuilder prop)
            => prop.HasConversion<DateTime?, DateTime?>(d => d != null ? d.Value.ToUniversalTime() : null, d => d == null ? null : IsAlreadyUtc(d.Value));

        private static DateTime IsAlreadyUtc(DateTime d)
        {
            Debug.Assert(d.Kind == DateTimeKind.Utc);
            return d;
        }

        public static void StoreEnumAsString<E>(this PropertyBuilder property) where E : struct
            => property.HasConversion<E, string>(v => v.ToString()!, v => Enum.Parse<E>(v));

        //byte[] Compress(int minItemsForCompression, byte[] bytes)
        //{
        //    using (DeflateStream compressionStream = new DeflateStream(compressedFileStream, CompressionMode.Compress))
        //    {
        //    if (values.Count >= minItemsForCompression) {
        //    }
        //    List<byte> blob = new List<byte>();
        //    foreach (float num in values) {
        //        
        //    }
        //}

        public static IServiceCollection Add<TService, TImplementation>(this IServiceCollection services, ServiceLifetime lifetime)
            where TService : class
            where TImplementation : class, TService
        {
            var descriptor = new ServiceDescriptor(typeof(TService), typeof(TImplementation), lifetime);
            services.Add(descriptor);
            return services;
        }

        /// <summary>This exists because we're not allowed to use 
        ///     <c>Enum.TryParse(s, out Enum e) ? e : default</c>
        /// in Entity Framework HasConversion functions, because they are expression
        /// trees and expression trees don't support `out` arguments.</summary>
        public static Enum TryParseEnum<Enum>(string s, Enum defaultValue) where Enum:struct =>
            System.Enum.TryParse<Enum>(s, out var e) ? e : defaultValue;

        /// <summary>Default length limit for comment columns. The PostgreSQL documentation 
        /// says that its length limits are on the number of characters, not the number of 
        /// bytes.</summary>
        public const int MaxCommentLen = 4000;
        /// <summary>Default length limit for string columns.</summary>
        public const int DefaultMaxStringLen = 200;
        /// <summary>Default length limit for file name columns.</summary>
        public const int MaxFileNameLen = 200;
    }
}