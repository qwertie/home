﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Barreleye.Migrations
{
    public partial class AddLastUpdatedDates : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Rename "license_files" table to "files", along with related indices and keys
            migrationBuilder.DropForeignKey(
                name: "fk_license_files_file_contents_content_hash",
                table: "license_files");

            migrationBuilder.DropForeignKey(
                name: "fk_license_files_scenarios_scenario_id",
                table: "license_files");

            migrationBuilder.DropPrimaryKey(
                name: "pk_license_files",
                table: "license_files");

            migrationBuilder.RenameTable(
                name: "license_files",
                newName: "files");

            migrationBuilder.RenameIndex(
                name: "ix_license_files_scenario_id",
                table: "files",
                newName: "ix_files_scenario_id");

            migrationBuilder.RenameIndex(
                name: "ix_license_files_content_hash",
                table: "files",
                newName: "ix_files_content_hash");

            migrationBuilder.AddPrimaryKey(
                name: "pk_files",
                table: "files",
                column: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_files_file_contents_content_hash",
                table: "files",
                column: "content_hash",
                principalTable: "file_contents",
                principalColumn: "hash",
                onDelete: ReferentialAction.SetNull);

            migrationBuilder.AddForeignKey(
                name: "fk_files_scenarios_scenario_id",
                table: "files",
                column: "scenario_id",
                principalTable: "scenarios",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            // Drop unused column from surface_locations
            migrationBuilder.DropColumn(
                name: "config",
                table: "surface_locations");

            // Apparently surface_locations.scenario_id wasn't already marked as a foreign key
            migrationBuilder.CreateIndex(
                name: "ix_surface_locations_scenario_id",
                table: "surface_locations",
                column: "scenario_id");

            migrationBuilder.AddForeignKey(
                name: "fk_surface_locations_scenarios_scenario_id",
                table: "surface_locations",
                column: "scenario_id",
                principalTable: "scenarios",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            // Add LastUpdated column in entities, connections, cost_line_items, files, surface_locations
            migrationBuilder.AddColumn<DateTime>(
                name: "last_updated",
                table: "entities",
                type: "timestamp without time zone",
                nullable: false,
                defaultValue: new DateTime(2020, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc));

            migrationBuilder.AddColumn<DateTime>(
                name: "last_updated",
                table: "connections",
                type: "timestamp without time zone",
                nullable: false,
                defaultValue: new DateTime(2020, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc));

            migrationBuilder.AddColumn<DateTime>(
                name: "last_updated",
                table: "cost_line_items",
                type: "timestamp without time zone",
                nullable: false,
                defaultValue: new DateTime(2020, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc));

            migrationBuilder.AddColumn<DateTime>(
                name: "last_updated",
                table: "files",
                type: "timestamp without time zone",
                nullable: false,
                defaultValue: new DateTime(2020, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc));

            migrationBuilder.AddColumn<DateTime>(
                name: "last_updated",
                table: "surface_locations",
                type: "timestamp without time zone",
                nullable: false,
                defaultValue: new DateTime(2020, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc));

            // Add new ScenarioId column to cost_line_items
            migrationBuilder.AddColumn<int>(
                name: "scenario_id",
                table: "cost_line_items",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.Sql(@"
                -- Assign a scenario_id to every cost_line_item
                UPDATE cost_line_items 
                    SET scenario_id = (
                        SELECT e.scenario_id
                        FROM entities e
                        WHERE cost_line_items.cost_set_id = e.cost_set_id
                    )
                    WHERE EXISTS (
                        SELECT 1
                        FROM entities e
                        WHERE cost_line_items.cost_set_id = e.cost_set_id
                    );

                UPDATE cost_line_items 
                    SET scenario_id = (
                      SELECT e.scenario_id
                      FROM preliminary_movements pm
                      INNER JOIN entities e ON pm.destination_id = e.id
                      WHERE cost_line_items.cost_set_id = pm.cost_set_id
                    )
                WHERE EXISTS (
                    SELECT 1
                    FROM preliminary_movements pm
                    INNER JOIN entities e ON pm.destination_id = e.id
                    WHERE cost_line_items.cost_set_id = pm.cost_set_id
                );

                -- We must delete any orphan line items with no matching scenario,
                -- so that the foreign key for scenario_id can be added.
                DELETE FROM cost_line_items
                    WHERE scenario_id = 0;
            ");

            migrationBuilder.CreateIndex(
                name: "ix_cost_line_items_scenario_id",
                table: "cost_line_items",
                column: "scenario_id");

            migrationBuilder.AddForeignKey(
                name: "fk_cost_line_items_scenarios_scenario_id",
                table: "cost_line_items",
                column: "scenario_id",
                principalTable: "scenarios",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_cost_line_items_scenarios_scenario_id",
                table: "cost_line_items");

            migrationBuilder.DropForeignKey(
                name: "fk_files_file_contents_content_hash",
                table: "files");

            migrationBuilder.DropForeignKey(
                name: "fk_files_scenarios_scenario_id",
                table: "files");

            migrationBuilder.DropForeignKey(
                name: "fk_surface_locations_scenarios_scenario_id",
                table: "surface_locations");

            migrationBuilder.DropIndex(
                name: "ix_surface_locations_scenario_id",
                table: "surface_locations");

            migrationBuilder.DropIndex(
                name: "ix_cost_line_items_scenario_id",
                table: "cost_line_items");

            migrationBuilder.DropPrimaryKey(
                name: "pk_files",
                table: "files");

            migrationBuilder.DropColumn(
                name: "last_updated",
                table: "surface_locations");

            migrationBuilder.DropColumn(
                name: "last_updated",
                table: "entities");

            migrationBuilder.DropColumn(
                name: "last_updated",
                table: "cost_line_items");

            migrationBuilder.DropColumn(
                name: "scenario_id",
                table: "cost_line_items");

            migrationBuilder.DropColumn(
                name: "last_updated",
                table: "connections");

            migrationBuilder.DropColumn(
                name: "last_updated",
                table: "files");

            migrationBuilder.RenameTable(
                name: "files",
                newName: "license_files");

            migrationBuilder.RenameIndex(
                name: "ix_files_scenario_id",
                table: "license_files",
                newName: "ix_license_files_scenario_id");

            migrationBuilder.RenameIndex(
                name: "ix_files_content_hash",
                table: "license_files",
                newName: "ix_license_files_content_hash");

            migrationBuilder.AddColumn<string>(
                name: "config",
                table: "surface_locations",
                type: "jsonb",
                nullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "pk_license_files",
                table: "license_files",
                column: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_license_files_file_contents_content_hash",
                table: "license_files",
                column: "content_hash",
                principalTable: "file_contents",
                principalColumn: "hash",
                onDelete: ReferentialAction.SetNull);

            migrationBuilder.AddForeignKey(
                name: "fk_license_files_scenarios_scenario_id",
                table: "license_files",
                column: "scenario_id",
                principalTable: "scenarios",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
