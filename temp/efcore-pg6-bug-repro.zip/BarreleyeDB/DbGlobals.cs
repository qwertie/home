﻿using System;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Barreleye
{
    /// <summary>Singleton services that the database layer uses, and global 
    /// database-related methods.</summary>
    public static class DbGlobals
    {
        public static IConfiguration Config = new ConfigurationBuilder()
            .AddJsonFile($"appsettings.json", true, true)
            #if DEBUG
            .AddJsonFile($"appsettings.Development.json", true, true)
            #endif
            .Build();
        public static IConfigurationSection ConnectionStrings => Config.GetSection("ConnectionStrings");

        public static ILoggerFactory LoggerFactory { get; set; } = new LoggerFactory();

        public static JsonSerializerOptions JsonOptions { get; set; } = InitJsonOptions();

        public static JsonSerializerOptions InitJsonOptions(JsonSerializerOptions? jsonOptions = null)
        {
            jsonOptions ??= new JsonSerializerOptions();
            //jsonOptions.Converters.Add(new JsonStringEnumConverter());
            //jsonOptions.Converters.Add(new JsonConverter_Double_NewtonsoftCompatble());
            //jsonOptions.Converters.Add(new JsonConverter_Float_NewtonsoftCompatble());
            //jsonOptions.Converters.Add(new JsonConverter_DateTime());
            //jsonOptions.Converters.Add(new JsonConverter_EntityConfig());
            //jsonOptions.Converters.Add(new JsonConverter_ByteArray());
            jsonOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
            jsonOptions.PropertyNameCaseInsensitive = true;
            #if DEBUG
            jsonOptions.WriteIndented = true;
            #endif
            return jsonOptions;
        }

        /// <summary>This should be called during startup if you'll be using 
        /// Microsoft.Extensions.DependencyInjection (e.g. ASP.NET Core MVC) to construct
        /// repositories automatically.</summary>
        public static void AddServices(IServiceCollection services, ServiceLifetime dbContextLifetime)
        {
            services.Add<DbContext, BarreleyeDbContext>(dbContextLifetime);
            services.Add<BarreleyeDbContext, BarreleyeDbContext>(dbContextLifetime);
        }

        /// <summary>Upgrades or creates the database, using the connection string
        /// provided in <c>Config.GetSection(\"ConnectionStrings\")</c>.</summary>
        public static void UpgradeOrCreateDatabase(Action<BarreleyeDbContext>? postUpgradeAction = null, string? connectionString = null)
        {
            using (var context = new BarreleyeDbContext(LoggerFactory, connectionString ?? ConnectionStrings["BarreleyeDB"]))
            {
                context.Database.Migrate();
                if (postUpgradeAction != null)
                    postUpgradeAction(context);
            }
        }
    }
}
