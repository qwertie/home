using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.AzureAppServices;
using NetTopologySuite.IO.Converters;

namespace Barreleye
{
    public class Program
    {
        public static void Main(string[] args)
        {
            PrepareTestDatabase(() => {
                string TestConnString = "Server=localhost;Port=5432;Database=bug_repro;User Id=postgres;Password=postgres;Include Error Detail=true";

                using (var context = new BarreleyeDbContext(DbGlobals.LoggerFactory, TestConnString)) {
                    context.Database.EnsureDeleted();
                }
                return TestConnString;
            });
        }

        static void PrepareTestDatabase(Func<string> getConnectionString)
        {
            var services = new ServiceCollection();
            IMvcBuilder mvc = services.AddControllersWithViews();

            ConfigureServicesUsedInBothTestsAndProduction(services, mvc);

            DbGlobals.JsonOptions = InitJsonOptions();

            // Build the dependency injection thingie, which makes instances of things
            var _serviceProvider = services.BuildServiceProvider();
            //_serviceScope = _serviceProvider.CreateScope();

            DbGlobals.LoggerFactory = _serviceProvider.GetRequiredService<ILoggerFactory>();

            var testConnString = getConnectionString();
            DbGlobals.Config = new Dictionary<string, string> {
                ["ConnectionStrings:BarreleyeDB"] = testConnString
            }.ToIConfiguration();

            DbGlobals.UpgradeOrCreateDatabase(context => {}, testConnString);

            var _context = _serviceProvider.GetRequiredService<BarreleyeDbContext>();
        }

        public static void ConfigureServicesUsedInBothTestsAndProduction(IServiceCollection services, IMvcBuilder mvc)
        {
            // Logging
            services.AddLogging((ILoggingBuilder builder) => {
                builder.AddConsole();
            });

            // Configure JSON serialization of our types in ASP.NET and in the database
            mvc.AddJsonOptions(options => DbGlobals.JsonOptions = InitJsonOptions(options.JsonSerializerOptions));

            // In ASP.NET Core apps, a Scope is created around each server request.
            // So these objects will be generated again for each HTTP request.
            DbGlobals.AddServices(services, ServiceLifetime.Scoped);
            //services.AddScoped<Presolver, Presolver>();
            //services.AddScoped<Postsolver, Postsolver>();
            //services.AddScoped<EntityManager, EntityManager>();
            //services.AddScoped<ConnectionManager, ConnectionManager>();
            //services.AddScoped<UserManager, UserManager>();
            //services.AddScoped<ScenarioManager, ScenarioManager>();
            //services.AddScoped<SurfaceLocationManager, SurfaceLocationManager>();
            //services.AddScoped<CostLineItemManager, CostLineItemManager>();
            //services.AddScoped<CostAccountingCodeManager, CostAccountingCodeManager>();
            //services.AddScoped<CostSetManager, CostSetManager>();
            //services.AddScoped<CostTypeManager, CostTypeManager>();
            //services.AddScoped<FileManager, FileManager>();
            //services.AddScoped<PrelimManager, PrelimManager>();
            //services.AddScoped<VolumeCache, VolumeCache>();
            //services.AddScoped<AttributionCache, AttributionCache>();
        }

        public static JsonSerializerOptions InitJsonOptions(JsonSerializerOptions? jsonOptions = null)
        {
            jsonOptions = DbGlobals.InitJsonOptions(jsonOptions);
            jsonOptions.Converters.Add(new GeoJsonConverterFactory());
            jsonOptions.AllowTrailingCommas = true;
            jsonOptions.ReadCommentHandling = JsonCommentHandling.Skip;
            jsonOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
            jsonOptions.PropertyNameCaseInsensitive = true;
            return jsonOptions;
        }
    }
    static class Ext
    {
        /// <summary>Converts a series of key-value pairs to an IConfigurationRoot
        /// (which is also an IConfiguration). Sections are supported via keys of
        /// the form "section:key"; for example if the key is "Sec:Key"
        /// then the returned IConfigurationRoot will have a section called "Sec"
        /// that contains a key called "Key".</summary>
        public static IConfigurationRoot ToIConfiguration(this IEnumerable<KeyValuePair<string, string>> dictionary)
        {
            var cfgBuilder = new ConfigurationBuilder();
            cfgBuilder.AddInMemoryCollection(dictionary);
            return cfgBuilder.Build();
        }
    }
}
