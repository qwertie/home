using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;

namespace Barreleye
{
    public class BarreleyeDbContext : DbContext
    {
        private readonly ILoggerFactory _loggerFactory;
        private readonly string _postgresConnectionString;

        // A parameterless constructor is required to generate migrations.
        // The command to add a migration is as follows:
        //
        //   dotnet ef migrations add <NAME> --project BarreleyeDB
        //
        // To view the SQL transaction for the new migration, use
        //
        //   dotnet ef migrations script <PREV_NAME> --project BarreleyeDB
        //
        // Where <PREV_NAME> is the name of the previous migration, including the timecode,
        // as specified in the [Migration] attribute in the .Designer.cs file.
        public BarreleyeDbContext()
            : this(DbGlobals.LoggerFactory, DbGlobals.ConnectionStrings["BarreleyeDB"]) { }

        // For use in tests
        public BarreleyeDbContext(ILoggerFactory loggerFactory, string postgreConnectionString)
        {
            (_loggerFactory, _postgresConnectionString) = (loggerFactory, postgreConnectionString);

            ChangeTracker.StateChanged += (sender, e) =>
            {
                //if (e.NewState is EntityState.Modified or EntityState.Added
                //    && e.Entry.Entity is IHasLastUpdated entity)
                //    entity.LastUpdated = DateTime.UtcNow;
            };
        }

        protected override void OnConfiguring(DbContextOptionsBuilder builder)
        {
            var connStr = _postgresConnectionString;
            builder.UseNpgsql(connStr, o => o.UseNetTopologySuite())
                .UseSnakeCaseNamingConvention(); //Ex. EntityName (C#) to entity_name (in DB)
            #if DEBUG
            builder.UseLoggerFactory(_loggerFactory);
            // This line causes logging of parameter values in SQL queries:
            builder.EnableSensitiveDataLogging();
            #endif
            builder.UseLazyLoadingProxies();
        }

        //public DbSet<EntityDBO>             Entities            { get; set; } = null!; // Assigned by EF Core
        //public DbSet<ConnectionDBO>         Connections         { get; set; } = null!; // Assigned by EF Core
        //public DbSet<ConnectionDataDBO>     ConnectionData      { get; set; } = null!; // Assigned by EF Core
        //public DbSet<Scenario>              Scenarios           { get; set; } = null!; // Assigned by EF Core

        //public DbSet<SurfaceLocation>       SurfaceLocations    { get; set; } = null!; // Assigned by EF Core
        //public DbSet<CostAccountingCodeDBO> CostAccountingCodes { get; set; } = null!;
        //public DbSet<CostSetDBO>            CostSets            { get; set; } = null!;
        //public DbSet<CostLineItemDBO>       CostLineItems       { get; set; } = null!;
        //public DbSet<CostTypeDBO>           CostTypes           { get; set; } = null!;
        //public DbSet<FileContentDBO>        FileContents        { get; set; } = null!;
        //public DbSet<LicenseFileDBO>        LicenseFiles        { get; set; } = null!;
        //public DbSet<PrelimDBO>             Prelims             { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.HasPostgresExtension("postgis");

            //Scenario       .OnModelCreating(builder);
            //ConnectionDBO  .OnModelCreating(builder);
            //EntityDBO      .OnModelCreating(builder);
            //PrelimDBO      .OnModelCreating(builder);
            //SurfaceLocation.OnModelCreating(builder);
            //CostLineItemDBO.OnModelCreating(builder);
            //LicenseFileDBO .OnModelCreating(builder);
            //FileContentDBO .OnModelCreating(builder);
        }
    } 
}